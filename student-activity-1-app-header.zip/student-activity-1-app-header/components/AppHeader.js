import * as React from 'react';
import { Text, View, TouchableOpacity, StyleSheet } from 'react-native';


class AppHeader extends React.Component {
  render( ){
  
   return(
     <View style={styles.textheader}>
      <Text style={styles.text}> Quiz Buzzer App </Text>
     </View>
   )
    
  }
    
  
}

const styles = StyleSheet.create({
  textheader: {
    backgroundColor:"blue"
  },
  text: {
    padding:20,
    fontWeight: 'bold',
    fontSize: 20,
    color:"white",
    textAlign:"center"
  }
});


export default AppHeader;